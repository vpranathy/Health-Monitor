<?php
$username="yuyangchen0122";
$password="a123123q45";
$database="fall2018softenggroup2health";
?>