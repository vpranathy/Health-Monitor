<?php

$host = "softenggroup2.czmkb4udcq6o.us-east-2.rds.amazonaws.com"
$db_user = "yuyangchen0122"
$db_password="a123123q45"
$db_name = "HealthMonitoring"


$con = mysqli_connect($host, $db_user, $db_password, $db_name);


?>